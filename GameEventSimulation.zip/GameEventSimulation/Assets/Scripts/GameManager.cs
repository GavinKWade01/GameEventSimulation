using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using UnityEditorInternal;
using UnityEngine;

public class GameManager : Singleton<GameManager>
{
    public delegate void RaceEvent(); 
    public static event RaceEvent StartRace;
    public static event RaceEvent StopRace;
    public float RaceTime;
    public bool RaceActive;

    public void StartTheRace()
    {
        if (StartRace != null)
        {
            StartRace();
        }
    }
    public  void StopTheRace(GameObject winner)
    {
        if (StopRace != null)
        {
            StopRace();
            RaceResults(winner);
        }
    }
     void RaceResults(GameObject winner)
    {
        Debug.Log($"{winner.name} won the race in {RaceTime}");
    }
    public void StartTimer()
    {
        RaceActive = true;
    }
    public void StopTimer()
    {
        RaceActive = false;
    }
    private void OnEnable()
    {
        StartRace += StartTimer;
        StopRace += StopTimer;
    }
    private void OnDisable()
    {
        StartRace -= StartTimer;
        StopRace -= StopTimer;
    }

    private void OnMouseDown()
    {
        StartTheRace();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!RaceActive)
        {
            return;
        }
        RaceTime += Time.deltaTime;
    }

}
