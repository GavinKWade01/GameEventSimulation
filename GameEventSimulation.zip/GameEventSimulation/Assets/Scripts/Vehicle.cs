using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour
{
    [SerializeField] Transform target;
    private float speed;
    bool shouldMove;
    private void OnEnable()
    {
        GameManager.StartRace += shouldStart;
        GameManager.StopRace += Stop;
    }
    private void OnDisable()
    {
        GameManager.StartRace -= shouldStart;
        GameManager.StopRace -= Stop;
    }
    // Start is called before the first frame update
    void Start()
    {
        speed = Random.Range(1f, 3f);
    }

    // Update is called once per frame
    void Update()
    {
        if (!shouldMove)
        {
            return;
        }
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed);
    }
    private void OnTriggerEnter(Collider other)
    {
        GameManager.Instance.StopTheRace(gameObject);
    }
    public void shouldStart()
    {
        shouldMove = true;
    }
    public void Stop()
    {
        shouldMove = false;
    }
}
